package com.example.EducationalGame;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducationalGameApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducationalGameApplication.class, args);
	}

}
