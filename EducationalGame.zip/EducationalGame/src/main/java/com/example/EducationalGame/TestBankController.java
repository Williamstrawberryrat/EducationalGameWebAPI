package com.example.EducationalGame;

import java.io.File;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.EducationalGame.TestBankService.Questions.Question;
import com.example.EducationalGame.TestBankService.Questions.TestBank;


@RestController
@RequestMapping("/testbank")
public class TestBankController {

    private final TestBank testBank = new TestBank();

    @CrossOrigin(origins = "*")
    @GetMapping("/load")
    public ResponseEntity<String> loadQuestions(@RequestParam String path) {
        if (path == null || path.isBlank()) {
            return ResponseEntity.badRequest().body("Path cannot be empty");
        }

        String normalized = path.replace("\\", "/");
        File folder = new File(normalized);

        if (!folder.exists() || !folder.isDirectory()) {
            return ResponseEntity.badRequest().body("Invalid folder: " + normalized);
        }

        boolean loaded = testBank.loadQuestions(folder);
        if (!loaded) {
            return ResponseEntity.status(500).body("Failed to load questions");
        }

        return ResponseEntity.ok("Questions loaded successfully");
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/question")
    public ResponseEntity<Question> getNextQuestion() {
        if (!testBank.iterator().hasNext()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(testBank.getNextQuestion());
    }

    @CrossOrigin(origins = "*")
    @GetMapping("/check/{index}")
    public ResponseEntity<Boolean> checkAnswer(@PathVariable int index) {
        try {
            boolean result = testBank.playing(index);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(false);
        }
    }
}